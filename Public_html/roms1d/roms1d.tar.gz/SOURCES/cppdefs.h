#define SALINITY	/* define if using salinity */
#define NONLIN_EOS	/* define if using nonlinear equation of state */

#define LMD_MIXING	/* Activate Large/McWilliams/Doney interior closure */
#define LMD_RIMIX	/* Add diffusivity due to shear instability */
#define LMD_DDMIX	/* Add convective mixing due to shear instability */
#define LMD_CONVEC	/* Add double-diffusive mixing */
#define LMD_KPP		/* turn ON or OFF surface boundary layer KPP mixing */
#define LMD_NONLOCAL	/* turn ON or OFF nonlocal transport */

#define BIOLOGY		/* define if using the biological model */
#undef  BIO_OCEAN	/* define if using oceanic species */
#ifdef  BIOLOGY
#  define OXYGEN	/* define if using oxygene */
#endif
#undef UPWELLING	/* define if parameterise an upwelling */
#ifdef  UPWELLING
#  undef SINUS_W	/* define if sinusoidal profile of vertical velocities */
#  undef LINEAR_W	/* define if linear profile of vertical velocities */
#  define PARAB_W	/* define if parabolic profile of vertical velocities */
#  define EXPORT 	/* define if parameterize horizontal advection */
#endif

#define NUDGE		/* Nudging profiles back to climatology (T,S,NO3) */

#define NCARG		/* Define if using NCAR graphics libraries */

#define RESTART_OUT	/* Dump a restart file */
#undef  RESTART_IN	/* Restart from a file */
#define BIN_OUTPUT	/* Binary output */
#define ASCII_OUTPUT	/* ASCII output */

#define FIRST_TIME_STEP iic.eq.ntstart
#define LAST_TIME_STEP iic.eq.ntimes+1
#define TIME_TO_WRITE tdays.gt.twrite.and.mod(iic-ntstart,noutput).eq.0
#define TIME_TO_PLOT tdays.gt.twrite.and.mod(iic-ntstart,nwrite).eq.0


