function [j,z,var]=tzplot(vname);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  plot a 1dv variable
%  
%  Inpout
%  vname (string) name of the var 'u','v','t1'...
%
%  Output
%  j: time in days
%  z: vertical coordinate
%  var: 1DV variable
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fname=[vname,'.dat'];
var=load(fname);
var=var';
j=load('days.dat');
z=load('z.dat');
zbl=load('zbl.dat');
pcolor(j,z,var);
shading interp
colorbar
hold on
h=plot(j,zbl,'k');
hold off
set(h,'LineWidth',2)
%xlabel('Time [Days]')
%ylabel('Depth [Meters]')
%title(vname)
