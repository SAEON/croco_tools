# LaTeX2HTML 2002-2-1 (1.70)
# Associate internals original text with physical files.


$key = q/cite_Jac95/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:temp_coupling/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:nestgui1/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Das94/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Deb03b/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Fla76/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Hai00/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Car05/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Dil03/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Shc03b/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Mar03/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:nestgui2/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:clim/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Con02/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Smi97/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Bla99/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Bla02/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Bec93/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:forcing/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Lar94/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Sta99/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Mar01/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Han91/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Mac02/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Deb03a/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Shc98/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:romsgui/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Pen01/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:grid/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Egb02/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Pen07/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Shc03a/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Rey94/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Cas99/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Pen04/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:open/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Deb00/;
$ref_files{$key} = "$dir".q|doc.html|; 
$noresave{$key} = "$nosave";

1;

